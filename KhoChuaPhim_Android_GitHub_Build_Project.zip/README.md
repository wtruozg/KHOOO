# KHO CHUA PHIM Android

Repo Android WebView build by GitHub Actions.

## Build APK
Vào Actions -> Build APK -> Run workflow.
APK nằm trong Artifacts.
